# Rosemary 功能图标

71 枚原创 SVG，24×24 网格，1.6px 圆角描边，使用 currentColor。图标按钮仍需可访问名称。正式品牌 Logo 不包含在这个图标包中。
