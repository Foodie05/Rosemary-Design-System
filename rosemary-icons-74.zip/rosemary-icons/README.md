# Rosemary functional icons

74 SVG icons. MIT licensed. 24-unit viewBox, 1.6-unit stroke, round caps and joins. Use currentColor. The included LICENSE applies to these functional icons; brand logos and marks are not included.
